package com.csv.com;

import java.io.File;
import java.io.PrintWriter;

public class create_csv {

	public static void main(String[] args) {
		
		try {
			
			PrintWriter pw=new PrintWriter(new File("D:\\lsn prog\\csv\\e_tab.csv")); 
			StringBuilder sb=new StringBuilder();
			
			sb.append("sl_no");
			sb.append(",");
			sb.append("e_name");
			sb.append(",");
			sb.append("e_id");
			sb.append(",");
			sb.append("e_title");
			sb.append(",");
			sb.append("e_exp(yrs)");
			sb.append(",");
			sb.append("e_age");
			sb.append("\n \r");
			
			sb.append("1");
			sb.append(",");
			sb.append("nikhil");
			sb.append(",");
			sb.append("123");
			sb.append(",");
			sb.append("java dev");
			sb.append(",");
			sb.append("2");
			sb.append(",");
			sb.append("21");
			sb.append("\n \r");
			
			sb.append("2");
			sb.append(",");
			sb.append("vishnu");
			sb.append(",");
			sb.append("124");
			sb.append(",");
			sb.append("testing");
			sb.append(",");
			sb.append("2");
			sb.append(",");
			sb.append("22");
			sb.append("\n \r");
			
			sb.append("3");
			sb.append(",");
			sb.append("vamshi");
			sb.append(",");
			sb.append("125");
			sb.append(",");
			sb.append("Marketing");
			sb.append(",");
			sb.append("2");
			sb.append(",");
			sb.append("21");
			sb.append("\n \r");
			
			sb.append("4");
			sb.append(",");
			sb.append("ranjeeth");
			sb.append(",");
			sb.append("126");
			sb.append(",");
			sb.append("qos");
			sb.append(",");
			sb.append("2");
			sb.append(",");
			sb.append("22");
			sb.append("\n \r");
			
			
			pw.write(sb.toString());
			pw.close();
			System.out.println("completed");
			
			
		}catch(Exception e) {
	}
		}

}
